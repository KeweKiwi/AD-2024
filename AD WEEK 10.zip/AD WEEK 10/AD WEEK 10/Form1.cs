﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;



namespace AD_WEEK_10
{
    public partial class PLAYER : Form
    {
        
        public PLAYER()
        {
            InitializeComponent();
        }
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        DataTable dtPlayer;
        int index = 0;

        private void PLAYER_Load(object sender, EventArgs e)
        {
            sqlConnect = new MySqlConnection("server = 192.168.88.201;" + "uid = student;" + "pwd=isbmantap;" + "database=premier_league");
            sqlConnect.Open();
            sqlConnect.Close();
            dtPlayer = new DataTable();

            string sqlQuery = "select p.player_id, p.player_name, p.birthdate, n.nation, t.team_name, p.team_number\r\nfrom team t, nationality n, player p\r\nwhere t.team_id = p.team_id AND  p.nationality_id = n.nationality_id;";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtPlayer);


            tbPlayerId.Text = dtPlayer.Rows[index]["player_id"].ToString();
            tbName.Text = dtPlayer.Rows[index]["player_name"].ToString();
            tbNationality.Text = dtPlayer.Rows[index]["nation"].ToString();
            dtpick.Value = Convert.ToDateTime(dtPlayer.Rows[index]["birthdate"]);
            numbering.Value = Convert.ToInt32(dtPlayer.Rows[index]["team_number"]);
            cbTeam.DataSource = dtPlayer;
            cbTeam.DisplayMember = "team_name";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //string sqlQuery = $"insert into mahasiswa (nim_mahasiswa, nama_mahasiswa, kota_asal) values ('{tbNim.Text}', '{tbNama.Text}', '{tbKota.Text}')";

        }

        private void btnkanan_Click(object sender, EventArgs e)
        {
            if(index == dtPlayer.Rows.Count-1)
            {

            }
            else
            {
                index++;
                tbPlayerId.Text = dtPlayer.Rows[index]["player_id"].ToString();
                tbName.Text = dtPlayer.Rows[index]["player_name"].ToString();
                tbNationality.Text = dtPlayer.Rows[index]["nation"].ToString();
                dtpick.Value = Convert.ToDateTime(dtPlayer.Rows[index]["birthdate"]);
                numbering.Value = Convert.ToInt32(dtPlayer.Rows[index]["team_number"]);
                cbTeam.DataSource = dtPlayer;
                cbTeam.DisplayMember = "team_name";
            }
            
        }

        private void btnkiri_Click(object sender, EventArgs e)
        {
            if (index == 0)
            {

            }
            else
            {
                index--;
                tbPlayerId.Text = dtPlayer.Rows[index]["player_id"].ToString();
                tbName.Text = dtPlayer.Rows[index]["player_name"].ToString();
                tbNationality.Text = dtPlayer.Rows[index]["nation"].ToString();
                dtpick.Value = Convert.ToDateTime(dtPlayer.Rows[index]["birthdate"]);
                numbering.Value = Convert.ToInt32(dtPlayer.Rows[index]["team_number"]);
                cbTeam.DataSource = dtPlayer;
                cbTeam.DisplayMember = "team_name";
            }

        }

        private void btnskipkiri_Click(object sender, EventArgs e)
        {
            index = 0;
            tbPlayerId.Text = dtPlayer.Rows[index]["player_id"].ToString();
            tbName.Text = dtPlayer.Rows[index]["player_name"].ToString();
            tbNationality.Text = dtPlayer.Rows[index]["nation"].ToString();
            dtpick.Value = Convert.ToDateTime(dtPlayer.Rows[index]["birthdate"]);
            numbering.Value = Convert.ToInt32(dtPlayer.Rows[index]["team_number"]);
            cbTeam.DataSource = dtPlayer;
            cbTeam.DisplayMember = "team_name";
        }
    }
}
