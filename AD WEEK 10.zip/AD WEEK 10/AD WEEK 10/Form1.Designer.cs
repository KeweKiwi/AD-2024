﻿namespace AD_WEEK_10
{
    partial class PLAYER
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnskipkiri = new System.Windows.Forms.Button();
            this.btnkiri = new System.Windows.Forms.Button();
            this.btnkanan = new System.Windows.Forms.Button();
            this.btnskipkanan = new System.Windows.Forms.Button();
            this.lblPlayerId = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblBirth = new System.Windows.Forms.Label();
            this.lblNat = new System.Windows.Forms.Label();
            this.lblTim = new System.Windows.Forms.Label();
            this.lblTimNum = new System.Windows.Forms.Label();
            this.tbPlayerId = new System.Windows.Forms.TextBox();
            this.tbName = new System.Windows.Forms.TextBox();
            this.dtpick = new System.Windows.Forms.DateTimePicker();
            this.cbTeam = new System.Windows.Forms.ComboBox();
            this.numbering = new System.Windows.Forms.NumericUpDown();
            this.tbNationality = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numbering)).BeginInit();
            this.SuspendLayout();
            // 
            // btnskipkiri
            // 
            this.btnskipkiri.Location = new System.Drawing.Point(140, 193);
            this.btnskipkiri.Name = "btnskipkiri";
            this.btnskipkiri.Size = new System.Drawing.Size(197, 159);
            this.btnskipkiri.TabIndex = 0;
            this.btnskipkiri.Text = "<<";
            this.btnskipkiri.UseVisualStyleBackColor = true;
            this.btnskipkiri.Click += new System.EventHandler(this.btnskipkiri_Click);
            // 
            // btnkiri
            // 
            this.btnkiri.Location = new System.Drawing.Point(464, 193);
            this.btnkiri.Name = "btnkiri";
            this.btnkiri.Size = new System.Drawing.Size(197, 159);
            this.btnkiri.TabIndex = 1;
            this.btnkiri.Text = "<";
            this.btnkiri.UseVisualStyleBackColor = true;
            this.btnkiri.Click += new System.EventHandler(this.btnkiri_Click);
            // 
            // btnkanan
            // 
            this.btnkanan.Location = new System.Drawing.Point(816, 193);
            this.btnkanan.Name = "btnkanan";
            this.btnkanan.Size = new System.Drawing.Size(197, 159);
            this.btnkanan.TabIndex = 2;
            this.btnkanan.Text = ">";
            this.btnkanan.UseVisualStyleBackColor = true;
            this.btnkanan.Click += new System.EventHandler(this.btnkanan_Click);
            // 
            // btnskipkanan
            // 
            this.btnskipkanan.Location = new System.Drawing.Point(1166, 193);
            this.btnskipkanan.Name = "btnskipkanan";
            this.btnskipkanan.Size = new System.Drawing.Size(197, 159);
            this.btnskipkanan.TabIndex = 3;
            this.btnskipkanan.Text = ">>";
            this.btnskipkanan.UseVisualStyleBackColor = true;
            // 
            // lblPlayerId
            // 
            this.lblPlayerId.AutoSize = true;
            this.lblPlayerId.Location = new System.Drawing.Point(50, 444);
            this.lblPlayerId.Name = "lblPlayerId";
            this.lblPlayerId.Size = new System.Drawing.Size(99, 25);
            this.lblPlayerId.TabIndex = 4;
            this.lblPlayerId.Text = "Player ID";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(50, 508);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(135, 25);
            this.lblName.TabIndex = 5;
            this.lblName.Text = "Player Name";
            // 
            // lblBirth
            // 
            this.lblBirth.AutoSize = true;
            this.lblBirth.Location = new System.Drawing.Point(50, 567);
            this.lblBirth.Name = "lblBirth";
            this.lblBirth.Size = new System.Drawing.Size(98, 25);
            this.lblBirth.TabIndex = 6;
            this.lblBirth.Text = "Birthdate";
            // 
            // lblNat
            // 
            this.lblNat.AutoSize = true;
            this.lblNat.Location = new System.Drawing.Point(50, 615);
            this.lblNat.Name = "lblNat";
            this.lblNat.Size = new System.Drawing.Size(113, 25);
            this.lblNat.TabIndex = 7;
            this.lblNat.Text = "Nationality";
            // 
            // lblTim
            // 
            this.lblTim.AutoSize = true;
            this.lblTim.Location = new System.Drawing.Point(50, 669);
            this.lblTim.Name = "lblTim";
            this.lblTim.Size = new System.Drawing.Size(66, 25);
            this.lblTim.TabIndex = 8;
            this.lblTim.Text = "Team";
            // 
            // lblTimNum
            // 
            this.lblTimNum.AutoSize = true;
            this.lblTimNum.Location = new System.Drawing.Point(50, 727);
            this.lblTimNum.Name = "lblTimNum";
            this.lblTimNum.Size = new System.Drawing.Size(147, 25);
            this.lblTimNum.TabIndex = 9;
            this.lblTimNum.Text = "Team Number";
            // 
            // tbPlayerId
            // 
            this.tbPlayerId.Location = new System.Drawing.Point(226, 444);
            this.tbPlayerId.Name = "tbPlayerId";
            this.tbPlayerId.Size = new System.Drawing.Size(100, 31);
            this.tbPlayerId.TabIndex = 10;
            // 
            // tbName
            // 
            this.tbName.Location = new System.Drawing.Point(226, 508);
            this.tbName.Name = "tbName";
            this.tbName.Size = new System.Drawing.Size(100, 31);
            this.tbName.TabIndex = 11;
            // 
            // dtpick
            // 
            this.dtpick.Location = new System.Drawing.Point(226, 567);
            this.dtpick.Name = "dtpick";
            this.dtpick.Size = new System.Drawing.Size(398, 31);
            this.dtpick.TabIndex = 12;
            // 
            // cbTeam
            // 
            this.cbTeam.FormattingEnabled = true;
            this.cbTeam.Location = new System.Drawing.Point(227, 661);
            this.cbTeam.Name = "cbTeam";
            this.cbTeam.Size = new System.Drawing.Size(121, 33);
            this.cbTeam.TabIndex = 13;
            // 
            // numbering
            // 
            this.numbering.Location = new System.Drawing.Point(228, 727);
            this.numbering.Name = "numbering";
            this.numbering.Size = new System.Drawing.Size(120, 31);
            this.numbering.TabIndex = 14;
            // 
            // tbNationality
            // 
            this.tbNationality.Location = new System.Drawing.Point(227, 615);
            this.tbNationality.Name = "tbNationality";
            this.tbNationality.Size = new System.Drawing.Size(100, 31);
            this.tbNationality.TabIndex = 15;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(228, 787);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(120, 34);
            this.btnSave.TabIndex = 16;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // PLAYER
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1477, 872);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.tbNationality);
            this.Controls.Add(this.numbering);
            this.Controls.Add(this.cbTeam);
            this.Controls.Add(this.dtpick);
            this.Controls.Add(this.tbName);
            this.Controls.Add(this.tbPlayerId);
            this.Controls.Add(this.lblTimNum);
            this.Controls.Add(this.lblTim);
            this.Controls.Add(this.lblNat);
            this.Controls.Add(this.lblBirth);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblPlayerId);
            this.Controls.Add(this.btnskipkanan);
            this.Controls.Add(this.btnkanan);
            this.Controls.Add(this.btnkiri);
            this.Controls.Add(this.btnskipkiri);
            this.Name = "PLAYER";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.PLAYER_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numbering)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnskipkiri;
        private System.Windows.Forms.Button btnkiri;
        private System.Windows.Forms.Button btnkanan;
        private System.Windows.Forms.Button btnskipkanan;
        private System.Windows.Forms.Label lblPlayerId;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblBirth;
        private System.Windows.Forms.Label lblNat;
        private System.Windows.Forms.Label lblTim;
        private System.Windows.Forms.Label lblTimNum;
        private System.Windows.Forms.TextBox tbPlayerId;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.DateTimePicker dtpick;
        private System.Windows.Forms.ComboBox cbTeam;
        private System.Windows.Forms.NumericUpDown numbering;
        private System.Windows.Forms.TextBox tbNationality;
        private System.Windows.Forms.Button btnSave;
    }
}

