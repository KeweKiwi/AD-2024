﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CA_Week_15
{
    public partial class HasilPertandingan : Form
    {

        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        string query;
        DataTable dTeamHome;
        DataTable dTeamAway;
        DataTable dmatch;
        DataTable manager;
        DataTable player;
        DataTable match;
        DataTable dt;
        string idhome;
        string idaway;
        string idmhome; string idmaway; string captain1; string captainaway;
        int indexRow;
        public HasilPertandingan()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dTeamHome = new DataTable();
            dTeamAway = new DataTable();
            manager = new DataTable();
            player = new DataTable();
            match = new DataTable();


            sqlConnect = new MySqlConnection("server=localhost;uid=root;pwd=isbmantap;database=premier_league");
            sqlConnect.Open();
            sqlConnect.Close();
            query = "select * from team;";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dTeamHome);
            sqlDataAdapter.Fill(dTeamAway);

            cbTHome.DataSource = dTeamHome;
            cbTHome.DisplayMember = "team_name";
            cbTHome.ValueMember = "team_id";
            cbTHome.SelectedIndex = -1;

            cbTAway.DataSource = dTeamAway;
            cbTAway.DisplayMember = "team_name";
            cbTAway.ValueMember = "team_id";
            cbTAway.SelectedIndex = -1;

            query = "select * from manager";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(manager);

            query = "select * from player";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(player);

            query = "select * from `match`";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(match);

        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            bool yn = false;
            for (int i = 0; i < match.Rows.Count; i++)
            {
                if (match.Rows[i][2].ToString() == cbTHome.SelectedValue.ToString() && match.Rows[i][3].ToString() == cbTAway.SelectedValue.ToString())
                {
                    yn = true;
                    indexRow = i;
                    break;
                }
            }
            if (yn)
            {
                lblDate.Text = match.Rows[indexRow][1].ToString();
                dt = new DataTable();
                dmatch = new DataTable();

                query = "select d.minute, p.player_name, d.type, d.team_id from dmatch d join player p on p.player_id = d.player_id order by 1;";
                sqlCommand = new MySqlCommand(query, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dt);

                dmatch.Columns.Add("minutes");
                dmatch.Columns.Add("Player Name 1");
                dmatch.Columns.Add("Tipe 1");
                dmatch.Columns.Add("Player Name 2");
                dmatch.Columns.Add("Tipe 2");
                dgv.DataSource = dmatch;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (dt.Rows[i][3].ToString() == cbTHome.SelectedValue.ToString())
                    {
                        dmatch.Rows.Add(dt.Rows[i][0].ToString(), dt.Rows[i][1].ToString(), dt.Rows[i][2].ToString(), " ", " ");
                    }
                    if (dt.Rows[i][3].ToString() == cbTAway.SelectedValue.ToString())
                    {
                        dmatch.Rows.Add(dt.Rows[i][0].ToString(), " ", " ", dt.Rows[i][1].ToString(), dt.Rows[i][2].ToString());
                    }
                }
                dgv.DataSource = dmatch;

            }
        }
    
           
            
        

        private void cbTHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbTHome.SelectedIndex == -1 && cbTAway.SelectedIndex == -1)
            {

            }
            else
            {
                if (cbTHome.SelectedIndex == cbTAway.SelectedIndex)
                {
                    MessageBox.Show("TAK BOLEH SAMA");
                }
                else
                {
                    idhome = cbTHome.SelectedValue.ToString();
                    for (int i = 0; i < dTeamHome.Rows.Count; i++)
                    {
                        if (dTeamHome.Rows[i][0].ToString() == idhome)
                        {
                            idmhome = dTeamHome.Rows[i][5].ToString();
                            captain1 = dTeamHome.Rows[i][7].ToString();
                            lblStadium.Text = dTeamHome.Rows[i][2].ToString();
                            lblCapacity.Text = dTeamHome.Rows[i][3].ToString();
                        }

                    }

                    for(int i = 0;i<manager.Rows.Count; i++)
                    {
                        lblMHome.Text = manager.Rows[i][1].ToString();  
                    }

                    for (int i = 0; i < player.Rows.Count; i++)
                    {
                        if (player.Rows[i][0].ToString() == captain1)
                        {
                            lblCHome.Text = player.Rows[i][2].ToString();

                        }
                    }
                }
            }
        }

        private void cbTAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbTHome.SelectedIndex == -1 && cbTAway.SelectedIndex == -1)
            {

            }
            else
            {
                if (cbTHome.SelectedIndex == cbTAway.SelectedIndex)
                {
                    MessageBox.Show("TAK BOLEH SAMA");
                }
                else
                {
                    idaway = cbTAway.SelectedValue.ToString();
                    for (int i = 0; i < dTeamAway.Rows.Count; i++)
                    {
                        if (dTeamAway.Rows[i][0].ToString() == idaway)
                        {
                            idmaway = dTeamAway.Rows[i][5].ToString();
                            captainaway = dTeamAway.Rows[i][7].ToString();
                        }

                    }

                    for (int i = 0; i < manager.Rows.Count; i++)
                    {
                        if (manager.Rows[i][0].ToString() == idmaway)
                        {
                            lblMAway.Text = manager.Rows[i][1].ToString();
                        }
                    }

                    for (int i = 0; i < player.Rows.Count; i++)
                    {
                        if (player.Rows[i][0].ToString() == captainaway)
                        {
                            lblCAway.Text = player.Rows[i][2].ToString();

                        }
                    }
                }
            }
        }
    }
}
