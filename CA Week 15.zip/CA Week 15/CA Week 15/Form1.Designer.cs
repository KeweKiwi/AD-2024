﻿namespace CA_Week_15
{
    partial class HasilPertandingan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbTHome = new System.Windows.Forms.ComboBox();
            this.cbTAway = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblMHome = new System.Windows.Forms.Label();
            this.lblCHome = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblMAway = new System.Windows.Forms.Label();
            this.lblCAway = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblStadium = new System.Windows.Forms.Label();
            this.lblCapacity = new System.Windows.Forms.Label();
            this.btnCheck = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lblScore = new System.Windows.Forms.Label();
            this.dgv = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // cbTHome
            // 
            this.cbTHome.FormattingEnabled = true;
            this.cbTHome.Location = new System.Drawing.Point(65, 56);
            this.cbTHome.Name = "cbTHome";
            this.cbTHome.Size = new System.Drawing.Size(455, 33);
            this.cbTHome.TabIndex = 0;
            this.cbTHome.SelectedIndexChanged += new System.EventHandler(this.cbTHome_SelectedIndexChanged);
            // 
            // cbTAway
            // 
            this.cbTAway.FormattingEnabled = true;
            this.cbTAway.Location = new System.Drawing.Point(1350, 56);
            this.cbTAway.Name = "cbTAway";
            this.cbTAway.Size = new System.Drawing.Size(455, 33);
            this.cbTAway.TabIndex = 1;
            this.cbTAway.SelectedIndexChanged += new System.EventHandler(this.cbTAway_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(65, 154);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Manager";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(65, 232);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Captain:";
            // 
            // lblMHome
            // 
            this.lblMHome.AutoSize = true;
            this.lblMHome.Location = new System.Drawing.Point(188, 154);
            this.lblMHome.Name = "lblMHome";
            this.lblMHome.Size = new System.Drawing.Size(70, 25);
            this.lblMHome.TabIndex = 4;
            this.lblMHome.Text = "label3";
            // 
            // lblCHome
            // 
            this.lblCHome.AutoSize = true;
            this.lblCHome.Location = new System.Drawing.Point(188, 232);
            this.lblCHome.Name = "lblCHome";
            this.lblCHome.Size = new System.Drawing.Size(70, 25);
            this.lblCHome.TabIndex = 5;
            this.lblCHome.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(891, 59);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 25);
            this.label5.TabIndex = 6;
            this.label5.Text = "label5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1368, 184);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 25);
            this.label6.TabIndex = 7;
            this.label6.Text = "Manager:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1368, 257);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 25);
            this.label7.TabIndex = 8;
            this.label7.Text = "Captain:";
            // 
            // lblMAway
            // 
            this.lblMAway.AutoSize = true;
            this.lblMAway.Location = new System.Drawing.Point(1506, 184);
            this.lblMAway.Name = "lblMAway";
            this.lblMAway.Size = new System.Drawing.Size(70, 25);
            this.lblMAway.TabIndex = 9;
            this.lblMAway.Text = "label8";
            // 
            // lblCAway
            // 
            this.lblCAway.AutoSize = true;
            this.lblCAway.Location = new System.Drawing.Point(1506, 257);
            this.lblCAway.Name = "lblCAway";
            this.lblCAway.Size = new System.Drawing.Size(70, 25);
            this.lblCAway.TabIndex = 10;
            this.lblCAway.Text = "label9";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(676, 443);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 25);
            this.label10.TabIndex = 11;
            this.label10.Text = "Stadium:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(676, 517);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(102, 25);
            this.label11.TabIndex = 12;
            this.label11.Text = "Capacity:";
            // 
            // lblStadium
            // 
            this.lblStadium.AutoSize = true;
            this.lblStadium.Location = new System.Drawing.Point(930, 443);
            this.lblStadium.Name = "lblStadium";
            this.lblStadium.Size = new System.Drawing.Size(82, 25);
            this.lblStadium.TabIndex = 13;
            this.lblStadium.Text = "label12";
            // 
            // lblCapacity
            // 
            this.lblCapacity.AutoSize = true;
            this.lblCapacity.Location = new System.Drawing.Point(930, 517);
            this.lblCapacity.Name = "lblCapacity";
            this.lblCapacity.Size = new System.Drawing.Size(82, 25);
            this.lblCapacity.TabIndex = 14;
            this.lblCapacity.Text = "label13";
            // 
            // btnCheck
            // 
            this.btnCheck.Location = new System.Drawing.Point(697, 602);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(315, 39);
            this.btnCheck.TabIndex = 15;
            this.btnCheck.Text = "CHECK";
            this.btnCheck.UseVisualStyleBackColor = true;
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(676, 690);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(96, 25);
            this.label14.TabIndex = 16;
            this.label14.Text = "Tanggal:";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(930, 690);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(82, 25);
            this.lblDate.TabIndex = 17;
            this.lblDate.Text = "label15";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(676, 747);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(62, 25);
            this.label16.TabIndex = 18;
            this.label16.Text = "Skor:";
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Location = new System.Drawing.Point(930, 747);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(82, 25);
            this.lblScore.TabIndex = 19;
            this.lblScore.Text = "label17";
            // 
            // dgv
            // 
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(17, 940);
            this.dgv.Name = "dgv";
            this.dgv.RowHeadersWidth = 82;
            this.dgv.RowTemplate.Height = 33;
            this.dgv.Size = new System.Drawing.Size(1899, 519);
            this.dgv.TabIndex = 20;
            // 
            // HasilPertandingan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1951, 1471);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.btnCheck);
            this.Controls.Add(this.lblCapacity);
            this.Controls.Add(this.lblStadium);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.lblCAway);
            this.Controls.Add(this.lblMAway);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblCHome);
            this.Controls.Add(this.lblMHome);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbTAway);
            this.Controls.Add(this.cbTHome);
            this.Name = "HasilPertandingan";
            this.Text = "Hasil pertandingan";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbTHome;
        private System.Windows.Forms.ComboBox cbTAway;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblMHome;
        private System.Windows.Forms.Label lblCHome;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblMAway;
        private System.Windows.Forms.Label lblCAway;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblStadium;
        private System.Windows.Forms.Label lblCapacity;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.DataGridView dgv;
    }
}

