﻿namespace AD_WEEK_11
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblData = new System.Windows.Forms.Label();
            this.tbMatch = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tbServer = new System.Windows.Forms.TextBox();
            this.tbUser = new System.Windows.Forms.TextBox();
            this.tbPass = new System.Windows.Forms.TextBox();
            this.tbDataBase = new System.Windows.Forms.TextBox();
            this.tbMatchID = new System.Windows.Forms.TextBox();
            this.cbTName = new System.Windows.Forms.ComboBox();
            this.matchDate = new System.Windows.Forms.DateTimePicker();
            this.cbTaway = new System.Windows.Forms.ComboBox();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.btnLogin = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(82, 103);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Server";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(82, 186);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "User";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(82, 273);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Password";
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Location = new System.Drawing.Point(82, 351);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(92, 25);
            this.lblData.TabIndex = 3;
            this.lblData.Text = "Datbase";
            // 
            // tbMatch
            // 
            this.tbMatch.AutoSize = true;
            this.tbMatch.Location = new System.Drawing.Point(565, 103);
            this.tbMatch.Name = "tbMatch";
            this.tbMatch.Size = new System.Drawing.Size(97, 25);
            this.tbMatch.TabIndex = 4;
            this.tbMatch.Text = "Match ID";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(534, 202);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(128, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "Team Name";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(776, 408);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 25);
            this.label7.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(943, 103);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(122, 25);
            this.label8.TabIndex = 6;
            this.label8.Text = "Match Date";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(943, 197);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(124, 25);
            this.label9.TabIndex = 7;
            this.label9.Text = "Team Away";
            // 
            // tbServer
            // 
            this.tbServer.Location = new System.Drawing.Point(200, 103);
            this.tbServer.Name = "tbServer";
            this.tbServer.Size = new System.Drawing.Size(100, 31);
            this.tbServer.TabIndex = 8;
            // 
            // tbUser
            // 
            this.tbUser.Location = new System.Drawing.Point(200, 191);
            this.tbUser.Name = "tbUser";
            this.tbUser.Size = new System.Drawing.Size(100, 31);
            this.tbUser.TabIndex = 9;
            // 
            // tbPass
            // 
            this.tbPass.Location = new System.Drawing.Point(200, 282);
            this.tbPass.Name = "tbPass";
            this.tbPass.Size = new System.Drawing.Size(100, 31);
            this.tbPass.TabIndex = 10;
            // 
            // tbDataBase
            // 
            this.tbDataBase.Location = new System.Drawing.Point(200, 351);
            this.tbDataBase.Name = "tbDataBase";
            this.tbDataBase.Size = new System.Drawing.Size(100, 31);
            this.tbDataBase.TabIndex = 11;
            // 
            // tbMatchID
            // 
            this.tbMatchID.Location = new System.Drawing.Point(686, 97);
            this.tbMatchID.Name = "tbMatchID";
            this.tbMatchID.Size = new System.Drawing.Size(100, 31);
            this.tbMatchID.TabIndex = 12;
            // 
            // cbTName
            // 
            this.cbTName.FormattingEnabled = true;
            this.cbTName.Location = new System.Drawing.Point(686, 197);
            this.cbTName.Name = "cbTName";
            this.cbTName.Size = new System.Drawing.Size(121, 33);
            this.cbTName.TabIndex = 13;
            this.cbTName.SelectedIndexChanged += new System.EventHandler(this.cbTName_SelectedIndexChanged);
            // 
            // matchDate
            // 
            this.matchDate.Location = new System.Drawing.Point(1062, 103);
            this.matchDate.Name = "matchDate";
            this.matchDate.Size = new System.Drawing.Size(200, 31);
            this.matchDate.TabIndex = 14;
            // 
            // cbTaway
            // 
            this.cbTaway.FormattingEnabled = true;
            this.cbTaway.Location = new System.Drawing.Point(1074, 194);
            this.cbTaway.Name = "cbTaway";
            this.cbTaway.Size = new System.Drawing.Size(121, 33);
            this.cbTaway.TabIndex = 15;
            this.cbTaway.SelectedIndexChanged += new System.EventHandler(this.cbTaway_SelectedIndexChanged);
            // 
            // dgv
            // 
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(423, 315);
            this.dgv.Name = "dgv";
            this.dgv.RowHeadersWidth = 82;
            this.dgv.RowTemplate.Height = 33;
            this.dgv.Size = new System.Drawing.Size(1001, 470);
            this.dgv.TabIndex = 16;
            // 
            // btnLogin
            // 
            this.btnLogin.Location = new System.Drawing.Point(120, 408);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(155, 43);
            this.btnLogin.TabIndex = 17;
            this.btnLogin.Text = "LOG IN";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1518, 826);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.cbTaway);
            this.Controls.Add(this.matchDate);
            this.Controls.Add(this.cbTName);
            this.Controls.Add(this.tbMatchID);
            this.Controls.Add(this.tbDataBase);
            this.Controls.Add(this.tbPass);
            this.Controls.Add(this.tbUser);
            this.Controls.Add(this.tbServer);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbMatch);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.Label tbMatch;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbServer;
        private System.Windows.Forms.TextBox tbUser;
        private System.Windows.Forms.TextBox tbPass;
        private System.Windows.Forms.TextBox tbDataBase;
        private System.Windows.Forms.TextBox tbMatchID;
        private System.Windows.Forms.ComboBox cbTName;
        private System.Windows.Forms.DateTimePicker matchDate;
        private System.Windows.Forms.ComboBox cbTaway;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Button btnLogin;
    }
}

