﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace AD_WEEK_11
{
    public partial class Form1 : Form
    {
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        MySqlConnection sqlConnect2;
        MySqlCommand sqlCommand2;
        MySqlDataAdapter sqlDataAdapter2;
        MySqlConnection sqlConnect3;
        MySqlCommand sqlCommand3;
        MySqlDataAdapter sqlDataAdapter3;
        DataTable dt;
        DataTable dt2;
        DataTable dt3;
        DataTable dt4;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            //sqlConnect= new MySqlConnection($"server={tbServer.Text};uid={tbUser.Text};pwd={tbPass.Text};database={tbDataBase.Text}");
            sqlConnect = new MySqlConnection($"server=localhost;uid=student;pwd=isbmantap;database=premier_league");
            sqlConnect.Open();
            sqlConnect.Close();
            dt= new DataTable();
            sqlConnect2 = new MySqlConnection($"server={tbServer.Text};uid={tbUser.Text};pwd={tbPass.Text};database={tbDataBase.Text}");
            dt2 = new DataTable();
            dt3 = new DataTable();

            string sqlQuery = $"SELECT dmatch.minute, team.team_name, player.player_name, dmatch.type\r\nfrom dmatch, team, player, `match` m\r\nWHERE dmatch.match_id = m.match_id AND player.player_id = dmatch.player_id AND dmatch.team_id = team.team_id\r\nand (m.team_home = '{cbTName.SelectedValue}' and m.team_away = '{cbTaway.SelectedValue}')\r\norder by 1\r\n;";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dt);
            dgv.DataSource = dt;


            string sqlQuery2 = "SELECT team.team_id, team.team_name From team;";
            sqlCommand = new MySqlCommand(sqlQuery2, sqlConnect);
            sqlDataAdapter= new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dt2);
            sqlDataAdapter.Fill(dt3);

            cbTName.DataSource = dt2;
            cbTName.DisplayMember = "team_name";
            cbTName.ValueMember = "team_id";

            cbTaway.DataSource = dt3;
            cbTaway.DisplayMember = "team_name";
            cbTaway.ValueMember = "team_id";

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        
        }

        private void cbTName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbTaway.SelectedIndex != 0 && cbTName.SelectedIndex != 0)
            {
                dt4 = new DataTable();
                string sqlQuery = $"SELECT dmatch.minute, team.team_name, player.player_name, dmatch.type\r\nfrom dmatch, team, player, `match` m\r\nWHERE dmatch.match_id = m.match_id AND player.player_id = dmatch.player_id AND dmatch.team_id = team.team_id\r\nand (m.team_home = '{cbTName.SelectedValue}' and m.team_away = '{cbTaway.SelectedValue}')\r\norder by 1\r\n;";

                sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dt);
                dgv.DataSource = dt;

                string sqlQuery2 = $"select m.match_date\r\nfrom `match` m\r\nwhere m.team_home = '{cbTName.SelectedValue}' and m.team_away = '{cbTaway.SelectedValue}';";

                sqlCommand = new MySqlCommand(sqlQuery2, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dt4);
                matchDate.Value = Convert.ToDateTime(dt4.Rows[0][0]);
            }
           
        }

        private void cbTaway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbTaway.SelectedIndex != 0 && cbTName.SelectedIndex != 0)
            {
                dt4 = new DataTable();
                string sqlQuery = $"SELECT dmatch.minute, team.team_name, player.player_name, dmatch.type\r\nfrom dmatch, team, player, `match` m\r\nWHERE dmatch.match_id = m.match_id AND player.player_id = dmatch.player_id AND dmatch.team_id = team.team_id\r\nand (m.team_home = '{cbTName.SelectedValue}' and m.team_away = '{cbTaway.SelectedValue}')\r\norder by 1\r\n;";

                sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dt);
                dgv.DataSource = dt;

                string sqlQuery2 = $"select m.match_date\r\nfrom `match` m\r\nwhere m.team_home = '{cbTName.SelectedValue}' and m.team_away = '{cbTaway.SelectedValue}';";

                sqlCommand = new MySqlCommand(sqlQuery2, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dt4);
                if(dt4.Rows .Count >0)
                {
                    matchDate.Value = Convert.ToDateTime(dt4.Rows[0][0]);

                }
            }
           
        }
    }
}
