﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        string[] hewanBuas = {"BabiHutan","bear","dinosaur","eagle","fox","Gajah","harimau","hiu","hyena","jerapah","leopard","Orca","singa","snake","wolves"};
        string[] hewanPeliharaan = { "Anjing", "Ayam", "Babi", "Bebek", "burung", "hamster", "IkanBuntal", "Kambing", "Kelinci", "Monke", "platypus", "Sapi", "SugarGlider", "Turtle" };
        string[] fotoBebas = {"umbel", "lucu"};
        int index = 0;
        int indexBuas = 0;
        int change = 1;
        int fotoBeb = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string alamat = "Y:\\Pets\\" + hewanPeliharaan[index] + ".jpg";
            pBox.Image = new Bitmap(alamat);
        }

        private void btnImage_Click(object sender, EventArgs e)
        {
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            string alamat = "";
            if (change == 1)
            {
                if (index == 13)
                {

                }
                else
                {
                    index++;

                }
                alamat = "Y:\\Pets\\" + hewanPeliharaan[index] + ".jpg";
                pBox.Image = new Bitmap(alamat);
            }
            else if (change == 2)
            {
                if (indexBuas == 14)
                {

                }
                else
                {
                    indexBuas++;

                }
                alamat = "Y:\\Wild\\" + hewanBuas[indexBuas] + ".jpg";
                pBox.Image = new Bitmap(alamat);
            }
            else if (change == 3)
            {
                if (fotoBeb == 1)
                {

                }
                else
                {
                    fotoBeb++;

                }
                alamat = "Y:\\Fotobebas\\" + fotoBebas[fotoBeb] + ".jpg";
                pBox.Image = new Bitmap(alamat);
            }

            
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            string alamat = "";
            if (change == 1)
            {
                if (index == 0)
                {

                }
                else
                {
                    index--;

                }
                alamat = "Y:\\Pets\\" + hewanPeliharaan[index] + ".jpg";
                pBox.Image = new Bitmap(alamat);
            }
            else if (change == 2)
            {
                if (indexBuas == 0)
                {

                }
                else
                {
                    indexBuas--;

                }
                alamat = "Y:\\Wild\\" + hewanBuas[indexBuas] + ".jpg";
                pBox.Image = new Bitmap(alamat);
            }
            else if (change == 3)
            {
                if (fotoBeb == 0)
                {

                }
                else
                {
                    fotoBeb--;

                }
                alamat = ":\\Fotobebas\\" + fotoBebas[fotoBeb] + ".jpg";
                pBox.Image = new Bitmap(alamat);
            }
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            if (change == 1)
            {
                change = 2;
                string isi = "Y:\\Wild\\" + hewanBuas[indexBuas] + ".jpg";
                pBox.Image = new Bitmap(isi);
            }
            else if (change == 2)
            {
                change = 3;
                string isi = "Y:\\Fotobebas\\" + fotoBebas[fotoBeb] + ".jpg";
                pBox.Image = new Bitmap(isi);
            }
            else if (change == 3)
            {
                change = 1;
                string isi = "Y:\\Pets\\" + hewanPeliharaan[index] + ".jpg";
                pBox.Image = new Bitmap(isi);
            }
        }
    }
}
