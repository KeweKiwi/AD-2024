﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace AD_week_14
{
    public partial class premier : Form
    {
        MySqlConnection sqlConnection;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        DataTable dtTeam = new DataTable();
        DataTable dtAway = new DataTable();
        DataTable players = new DataTable();
        DataTable dt = new DataTable();
        string query;
        string idhome;
        string idaway;
        string idteam;
        int index = 0;

        public premier()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            sqlConnection = new MySqlConnection("server=localhost;uid=root;pwd=isbmantap;database=premier_league");
            dtTeam = new DataTable();
            dtAway = new DataTable();
            sqlConnection.Open();
            sqlConnection.Close();
            query = "select team_id, team_name from team t";
            sqlCommand = new MySqlCommand(query, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtTeam);
            sqlDataAdapter.Fill(dtAway);
            cbTHome.DataSource = dtTeam;
            cbTHome.DisplayMember = "team_name";
            cbTHome.ValueMember = "team_id";
            cbTAway.DataSource = dtAway;
            cbTAway.DisplayMember = "team_name";
            cbTAway.ValueMember = "team_id";
            dt.Columns.Add("Minute");
            dt.Columns.Add("Team");
            dt.Columns.Add("Player");
            dt.Columns.Add("Type");

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            dt.Rows.Add(tbMinute.Text, cbTeam.Text, cbPlayer.Text, cbType.Text);
            dgv.DataSource = dt;
        }

        private void dTime_ValueChanged(object sender, EventArgs e)
        {
            string year = dTime.Value.Year.ToString();
            query = $"select count(match_id) from `match` where match_id like '{year}%';";
            sqlCommand = new MySqlCommand(query, sqlConnection);
            DataTable dtCount = new DataTable();
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtCount);

            if (Convert.ToInt32(dtCount.Rows[0][0])<10)
            {
                tbMatchID.Text = $"{year}00{(Convert.ToInt32(dtCount.Rows[0][0])+1).ToString()}";

            }
            else if (Convert.ToInt32(dtCount.Rows[0][0]) >= 10 && Convert.ToInt32(dtCount.Rows[0][0]) < 100)
            {
                tbMatchID.Text = $"{year}0{(Convert.ToInt32(dtCount.Rows[0][0]) + 1).ToString()}";
            }
            else if (Convert.ToInt32(dtCount.Rows[0][0]) >= 100)
            {
                tbMatchID.Text = $"{year}{(Convert.ToInt32(dtCount.Rows[0][0]) + 1).ToString()}";
            }
        }

        private void cbTHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbTHome.SelectedIndex == -1 && cbTAway.SelectedIndex ==-1)
            {

            }
            else
            {
                if (cbTAway.Text == cbTHome.Text)
                {
                    MessageBox.Show("Team Home tidk boleh sama");
                }
                else
                {
                    cbTeam.Items.Clear();
                    idhome =  Convert.ToString(cbTHome.SelectedValue);
                    idaway =  Convert.ToString(cbTAway.SelectedValue);
                    cbTeam.Items.Add(cbTHome.Text);
                    cbTeam.Items.Add(cbTAway.Text);

                }
            }
        }

        private void cbTAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbTHome.SelectedIndex == -1 && cbTAway.SelectedIndex == -1)
            {

            }
            else
            {
                if (cbTAway.Text == cbTHome.Text)
                {
                    MessageBox.Show("Team Home tidk boleh sama");
                }
                else
                {
                    cbTeam.Items.Clear();
                    idhome = Convert.ToString(cbTHome.SelectedValue);
                    idaway = Convert.ToString(cbTAway.SelectedValue);
                    cbTeam.Items.Add(cbTHome.Text);
                    cbTeam.Items.Add(cbTAway.Text);

                }
            }
        }

        private void cbTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            players = new DataTable();
            if (cbTeam.SelectedIndex == 0)
            {
                idteam = idhome;
            }
            if (cbTeam.SelectedIndex == 1)
            {
                idteam = idaway;
            }
            query = $"select player_id, player_name from player where team_id like '%{idteam}%'";
            sqlCommand = new MySqlCommand(query, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(players);
            cbPlayer.DataSource = players;
            cbPlayer.DisplayMember = "player_name";
            cbPlayer.ValueMember = "player_id";

        }

        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            index = e.RowIndex;
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            dt.Rows.RemoveAt(index);
            dgv.DataSource = dt;
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            foreach (DataRow row in dt.Rows)
            {
                
            }
            try
            {
                query = $"insert into `match` values ({tbMatchID.Text}, {dTime.Value}, {idhome}, {idaway}, goal_home, goal_away, M002, 0";
                sqlCommand = new MySqlCommand(query, sqlConnection);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            try
            {
                query = $"insert into `dmatch` values ({tbMatchID.Text}, {tbMinute.Text}', team_id, player_id, {cbType.SelectedValue}, 0";
                sqlCommand = new MySqlCommand(query, sqlConnection);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
