﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_WEEK9
{
    public partial class FormAddcs : Form
    {
        Form1 form1 =Application.OpenForms["Form1"] as Form1;

        public FormAddcs()
        {
            InitializeComponent();
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {

            bool yes = true;
            int index = 0;
            for (int i = 0; i < form1.listName.Count; i++)
            {
                if (form1.listName[i] == tbAddUser.Text)
                {
                    MessageBox.Show("SAMA WOOOI");
                    yes = false;
                    break;
                }
            }
            if (yes == true)
            {
                if (tbConfirm.Text == tbAddPass.Text)
                {
                    
                    form1.listName.Add(tbAddUser.Text);
                    form1.pass.Add(tbAddPass.Text);
                    MessageBox.Show("BERHASIL");
                    tbAddPass.Clear();
                    tbConfirm.Clear();
                    tbAddUser.Clear();
                }
                else
                {
                    MessageBox.Show("ADa yang janggal nih");
                }
            }
            
            
            
        }

        private void FormAddcs_Load(object sender, EventArgs e)
        {

        }
    }
}
