﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_WEEK9
{
    public partial class Form1 : Form
    {
        public List<string> listName = new List<string>();
        public List<string> pass = new List<string>();
        bool useryes = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            bool yes = false;
            int index = 0;
            for (int i = 0; i < listName.Count; i++)
            {
                if (listName[i] == tbUser.Text)
                {
                    index = i;
                    break;
                }
            }
            if (pass[index] == tbPass.Text)
            {
                yes = true;
            }
            else
            {
                yes = false;
            }

            if (yes == true)
            {
                FormMain frm = new FormMain();
                frm.Nama(tbUser.Text);
                frm.Show();
            }
            else if (yes == false)
            {
                MessageBox.Show("TYDAK KETEMU");
            }

            



        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listName.Add("admin");
            pass.Add("admin");
        }
    }
}
